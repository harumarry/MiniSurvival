using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    [SerializeField] float moveSpeed = 3f;   
    [HideInInspector] public Transform player;

    Rigidbody2D rb;

    Vector2 moveDirection;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        if (player == null) return;

        // �÷��̾� ��ġ���� ���� ���
        moveDirection = (player.position - transform.position).normalized;
        // �̵�
        rb.velocity = moveDirection * moveSpeed;
    }

    private void OnDisable()
    {
        if (rb != null)
        {
            rb.velocity = Vector2.zero;
        }
    }
}
